import { Component, OnInit } from '@angular/core';
import { FirebaseService } from '../services/firebase/firebase.service';
import { AuthService } from '../services/firebase/auth.service';
import { Router } from '@angular/router'
import { UserInfo } from '../models/user.info';
@Component({
    selector: 'app-create-user',
    templateUrl: './create-user.component.html',
    styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {

    userInfo: UserInfo;
    constructor(private fireService: FirebaseService, private authService: AuthService,
        private route: Router) { }


    ngOnInit() {
    }

    createAdminUser() {
        let input = this.createDifferentUserObjLocaltesting();

        this.authService.signUp(input.email, input.password).subscribe((res) => {
            this.fireService.addUser(res.uid, this.createAdminUserJSON(input)).subscribe((res) => {
                this.fireService.setLoginUserDetail(res);
                this.route.navigate(['/dashboard']);
            }, (err) => { console.log(err) });

            let area = input.area;
            let reqValue = area + 'List';

            switch (area) {
                case "state":
                    this.fireService.addUserState(res.uid, input[reqValue]);
                    break;
                case "district":
                    this.fireService.addUserDistrict(res.uid, input[reqValue]);
                    break;
                case "pincode":
                    this.fireService.addUserPincode(res.uid, input[reqValue]);
                    break;
            }

        },
            err => alert("errro")
        );
    }

    createAdminUserJSON(input) {
        return {
            userName: input.userName,
            name: input.name,
            email: input.email,
            telephone: input.telephone,
            userType: input.userType,
            department: input.department,
            area: input.area,
            profileImg: input.profileImg
        };
    }

    createDifferentUserObjLocaltesting() {
        var userState = {
            email: "pankajsoni91@gmail.com",
            password: "123456",
            userName: "@Pankaj",
            name: "Pankaj Soni",
            telephone: "9899010366",
            userType: "L1",
            department: "",
            area: "state",
            profileImg: "localAvatarImage",
            stateList: [{ code: "HAR" }, { code: "UP" }, { code: "PB" }],
            districtList: "",
            pincodeList: ""
        };

        var userDistrict = {
            email: "pankajsonidist@gmail.com",
            password: "123456",
            userName: "@Pankaj",
            name: "Pankaj Soni",
            telephone: "9899010366",
            userType: "L1",
            department: "",
            area: "district",
            profileImg: "localAvatarImage",
            stateList: "HAR",
            districtList: [{ code: "BWN" }, { code: "HIS" }, { code: "RTK" }],
            pincodeList: ""
        };

        var userPin = {
            email: "pankajsonipin@gmail.com",
            password: "123456",
            userName: "@Pankaj",
            name: "Pankaj Soni",
            telephone: "9899010366",
            userType: "L1",
            department: "",
            area: "pincode",
            profileImg: "localAvatarImage",
            stateList: "",
            districtList: "BWN",
            pincodeList: [{ code: "127021" }, { code: "127022" }, { code: "127024" }],
        };

        return userPin;
    }
}

