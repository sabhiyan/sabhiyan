import { Component } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../services/firebase/auth.service';
import { FirebaseService } from '../services/firebase/firebase.service';
import { Router } from '@angular/router'
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  myLoginForm: FormGroup;

  constructor(private fb: FormBuilder,
    private authService: AuthService,
    private fireService: FirebaseService,
    private route: Router) {
    this.myLoginForm = this.fb.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  login() {
    const formValue = this.myLoginForm.value;
    this.authService.login(formValue.email, formValue.password)
      .subscribe((res) => {
        console.log("after login");
        this.fireService.getUserDetail(res.uid).subscribe((res) => {
          this.fireService.setLoginUserDetail(res);
          this.route.navigate(['/dashboard']);
        },
          err => { }
        );
      },
      err => console.log(err)
      );
  }


}
