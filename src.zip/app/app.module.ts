import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

// Route
import { RouterModule } from '@angular/router';
import { ROUTER_CONFIG } from './router.config';

// Angular Fire2 configuration
import { AngularFireModule , FIREBASE_PROVIDERS} from 'angularfire2';
import { firebaseConfig, authConfig } from '../environments/firebase.config'

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';

// Service
import { UtilService } from './services/shared/util.service';
import { AuthService } from './services/firebase/auth.service';
import { FirebaseService } from './services/firebase/firebase.service';

// Component
import { TopNavComponent } from './sharedComponent/top-nav/top-nav.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CreateTicketComponent } from './create-ticket/create-ticket.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { TicketDescComponent } from './ticket-desc/ticket-desc.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    TopNavComponent,
    RegisterComponent,
    HomeComponent,
    DashboardComponent,
    CreateTicketComponent,
    CreateUserComponent,
    TicketDescComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forRoot(ROUTER_CONFIG),
    AngularFireModule.initializeApp(firebaseConfig, authConfig)
  ],
  providers: [AuthService, UtilService, FirebaseService, FIREBASE_PROVIDERS],
  bootstrap: [AppComponent]
})
export class AppModule { }
