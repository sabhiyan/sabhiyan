import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { FirebaseService } from '../services/firebase/firebase.service';
import { UserInfo } from '../models/user.info';
import { TicketInfo } from '../models/ticket.info';
import { AttachmentInfo } from '../models/attachment.info';
import { CommentInfo } from '../models/comment.info';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
    userInfo: UserInfo;
    searchParam: any[] = [];
    ticketDetailArr: any[] = [];
    completeTicketDetail: TicketInfo;
    completeTicketAttachment: AttachmentInfo[] = [];
    completeTicketComment: CommentInfo[] = [];

    constructor(private fireService: FirebaseService) { }

    ngOnInit() {
        console.log("in initi ");
        this.fireService.userDetail$.subscribe((userDetail) => {

            this.userInfo = userDetail;
            if (userDetail.$key) {
                if (userDetail.userType) {
                    console.log(userDetail);
                    let node = {
                        state: "user_state/" + userDetail.$key,
                        district: "user_dist/" + userDetail.$key,
                        pincode: "user_pin/" + userDetail.$key
                    }

                    this.fireService.getPassedNodeData(node[userDetail.area]).subscribe((res) => {
                        res.forEach(element => {
                            if (element.code) {
                                this.searchParam.push(element.code);
                            }
                        });

                        let area = userDetail.area;
                        this.ticketDetailArr = [];

                        this.searchParam.forEach(element => {
                            this.fireService.getTicketDetails(area, element).subscribe((res) => {
                                if (res.length) {

                                    this.getSpecificNodeData(res[0]);

                                    res.forEach(element => {
                                        this.ticketDetailArr.push(element);
                                    });
                                }
                            });
                        });

                    });

                }
            }
        });
    }

    getSpecificNodeData(clickedTicket) {
        this.resetData();
        let node = {
            attachementArr: "ticket/attachemntInfo/",
            commentArr: "ticket/comment/"
        }
        this.completeTicketDetail = clickedTicket;

        this.fireService.getPassedNodeData(node.attachementArr + this.completeTicketDetail.$key).subscribe((res) => {
            res.forEach(element => {
                console.log(element);
                this.completeTicketAttachment.push(element);
            });
        });

        this.fireService.getPassedNodeData(node.commentArr + this.completeTicketDetail.$key).subscribe((res) => {
            res.forEach(element => {
                this.completeTicketComment.push(element);
            });
        });

    }

    resetData() {
        this.completeTicketAttachment = [];
        this.completeTicketComment = [];
    }


}
