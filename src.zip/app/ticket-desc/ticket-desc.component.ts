import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FirebaseService } from '../services/firebase/firebase.service';
import { TicketInfo } from '../models/ticket.info';
import { CommentInfo } from '../models/comment.info';
import { AttachmentInfo } from '../models/attachment.info';

@Component({
    selector: 'app-ticket-desc',
    templateUrl: './ticket-desc.component.html',
    styleUrls: ['./ticket-desc.component.css']
})
export class TicketDescComponent implements OnInit {

    ticketInfo: TicketInfo;
    commentArr: CommentInfo[] = [];
    attachmentArr: AttachmentInfo[] = [];

    constructor(public route: Router, public currRoute: ActivatedRoute,
        private fireService: FirebaseService) {

    }

    ngOnInit() {
        let ticketId = this.currRoute.snapshot.params['ticketId'];
        // get all the detail of the ticket id ticket/ticketDetail/TICID 
        this.fireService.getPassedNodeObjectData(`ticket/ticketDetail/${ticketId}`).subscribe((res) => {
            this.ticketInfo = TicketInfo.fromJSON(res);
        });
        // get the attachement detail ticket/attachemntInfo/TICID
        this.fireService.getPassedNodeData(`ticket/attachemntInfo/${ticketId}`).subscribe((res) => {
            this.attachmentArr = AttachmentInfo.fromJsonList(res);
        });
        // get the comment detail ticket/comment/TICID
        this.fireService.getPassedNodeData(`ticket/comment/${ticketId}`).subscribe((res) => {
            this.commentArr = CommentInfo.fromJsonList(res);
        });
    }

}
