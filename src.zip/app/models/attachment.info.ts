export class AttachmentInfo {

    constructor(public $key: string,
        public location: string,
        public pincode: string,
        public uploadedDate: string,
        public userId: string,
        public fileLocation: string,
        public fileName: string
    ) {

    }

    static fromJsonList(array): AttachmentInfo[] {
        return array.map(AttachmentInfo.fromJSON);
    }

    static fromJSON({ $key, location, pincode, uploadedDate, userId, fileLocation, fileName }): AttachmentInfo {
        return new AttachmentInfo(
            $key,
            location,
            pincode,
            uploadedDate,
            userId,
            fileLocation,
            fileName
        );
    }
}