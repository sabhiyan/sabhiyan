export class TicketInfo {

    constructor(public $key: string,
        public createUserId: string,
        public currAssigneeId: string,
        public ticketDec: string,
        public createdDate: string,
        public modifyDate: string,
        public ticketStatus: string,
        public categoryType: string,
        public location: string,
        public localAddress: string,
        public district: string,
        public state: string,
        public pincode: string,
        public currentAssigneeDep: string,
        public dep_state: string,
        public dep_dist: string,
        public dep_pincode: string,
        public voteup_count: string
    ) {

    }

    static fromJsonList(array): TicketInfo[] {
        return array.map(TicketInfo.fromJSON);
    }

    static fromJSON({$key, createUserId, currAssigneeId, ticketDec, createdDate, modifyDate, ticketStatus, categoryType,
        location, localAddress, district, state, pincode, currentAssigneeDep, dep_state, dep_dist, dep_pincode, voteup_count }): TicketInfo {
        return new TicketInfo(
            $key,
            createUserId,
            currAssigneeId,
            ticketDec,
            createdDate,
            modifyDate,
            ticketStatus,
            categoryType,
            location,
            localAddress,
            district,
            state,
            pincode,
            currentAssigneeDep,
            dep_state,
            dep_dist,
            dep_pincode,
            voteup_count
        );
    }
}