export class UserInfo {

    constructor(public $key: string,
        public userName: string,
        public name: string,
        public email: string,
        public telephone: string,
        public userType: string,
        public department: string,
        public area: string,
        public profileImg: string

    ) {
    }

    static fromJsonList(array): UserInfo[] {
        return array.map(UserInfo.fromJSON);
    }

    static fromJSON({$key, userName, name, email, telephone, userType, department, area, profileImg}): UserInfo {
        return new UserInfo(
            $key,
            userName,
            name,
            email,
            telephone,
            userType,
            department,
            area,
            profileImg
        );
    }
}