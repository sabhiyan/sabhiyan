export class CommentInfo {

    constructor(public $key: string,
        public userId: string,
        public userName: string,
        public createDate: string,
        public userProfilePic: string,
        public commentDes: string,
        public attachmentNames: string
    ) {

    }

    static fromJsonList(array): CommentInfo[] {
        return array.map(CommentInfo.fromJSON);
    }


    static fromJSON({ $key, userId, userName, createDate, userProfilePic, commentDes, attachmentNames }): CommentInfo {
        return new CommentInfo(
            $key,
            userId,
            userName,
            createDate,
            userProfilePic,
            commentDes,
            attachmentNames
        );
    }
}