export class AdminUserInfo {

    constructor(public $key: string,
        public name: string,
        public email: string,
        public admin: string) {
    }

    static fromJsonList(array): AdminUserInfo[] {
        return array.map(AdminUserInfo.fromJSON);
    }

    static fromJSON({$key, name, email, admin}): AdminUserInfo {
        return new AdminUserInfo(
            $key,
            name,
            email,
            admin
        );
    }
}