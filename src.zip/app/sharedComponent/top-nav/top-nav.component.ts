import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/firebase/auth.service';
import { FirebaseService } from '../../services/firebase/firebase.service';
import { AuthInfo } from '../../models/auth.info';
import { UserInfo } from '../../models/user.info';
import { Router } from '@angular/router';
@Component({
  selector: 'app-top-nav',
  templateUrl: './top-nav.component.html',
  styleUrls: ['./top-nav.component.css']
})
export class TopNavComponent implements OnInit {

  authInfo: AuthInfo;
  userInfo: UserInfo;

  constructor(private auth: AuthService,
    private fireService: FirebaseService,
    private route: Router) { }

  ngOnInit() {
    this.auth.authInfo$.subscribe((authInfo) => this.authInfo = authInfo);
    this.fireService.userDetail$.subscribe((userDetail) => this.userInfo = userDetail);
  }

  logOut() {
    this.auth.logOut();
    this.route.navigate(['/login']);
  }

}
