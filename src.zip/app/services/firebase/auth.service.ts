import { Injectable, Inject } from '@angular/core';
import { Observable, BehaviorSubject, Subject } from 'rxjs/Rx';
import { AngularFireAuth } from 'angularfire2';
import { AuthInfo } from '../../models/auth.info';
import { FirebaseService } from './firebase.service';

@Injectable()
export class AuthService {

  static UNKNOWN_USER = new AuthInfo(null);
  authInfo$: BehaviorSubject<AuthInfo> = new BehaviorSubject<AuthInfo>(AuthService.UNKNOWN_USER);

  constructor(private auth: AngularFireAuth, @Inject(FirebaseService) fireService: FirebaseService) {

    this.auth.subscribe(user => {
      if (user) {
        // user logged in
        console.log('in auth service subscribe');
        const auth = new AuthInfo(user.uid);
        this.authInfo$.next(auth);
        fireService.getUserDetail(user.uid).subscribe(
          (res) => {
            fireService.setLoginUserDetail(res);
          }
        );
      }
      else {
        // user not logged in
        this.authInfo$.next(AuthService.UNKNOWN_USER);
      }
    });
  }

  login(email, password): Observable<any> {
    return this.promiseToObservable(this.auth.login({ email, password }));
  }

  signUp(email, password): Observable<any> {
    return this.promiseToObservable(this.auth.createUser({ email, password })).take(1);
  }

  logOut() {
    this.auth.logout();
    this.authInfo$.next(AuthService.UNKNOWN_USER);
  }

  promiseToObservable(promise): Observable<any> {
    const subject = new Subject<any>();
    promise.then(res => {
      const auth = new AuthInfo(this.auth.getAuth().uid);
      this.authInfo$.next(auth);
      subject.next(res);
      subject.complete();
    }, err => {
      this.authInfo$.next(AuthService.UNKNOWN_USER);
      subject.error(err);
      subject.complete();
    });
    return subject.asObservable();
  }
}
