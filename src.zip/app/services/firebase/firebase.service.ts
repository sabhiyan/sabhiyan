import { Injectable, Inject } from '@angular/core';
import { AngularFire, FirebaseApp, FirebaseObjectObservable, FirebaseRef } from 'angularfire2';
import { UserInfo } from '../../models/user.info';
import { TicketInfo } from '../../models/ticket.info';
import { BehaviorSubject, Observable, Subject } from 'rxjs/Rx';
import { Router } from '@angular/router';
import * as firebase from 'firebase';

declare var $: any;

@Injectable()
export class FirebaseService {

    static UNKNOWN_USER = new UserInfo("", "", "", "", "", "", "", "", "");
    userDetail$: BehaviorSubject<UserInfo> = new BehaviorSubject<UserInfo>(FirebaseService.UNKNOWN_USER);
    userDetailInfo: UserInfo;
    constructor(private af: AngularFire,
        private route: Router,
        @Inject(FirebaseApp) public firebaseApp: any) {

    }

    addUser(uid, user): Observable<any> {
        var ref = "users/" + uid;
        this.promiseToObservable(this.af.database.object(ref).update(user));
        return this.af.database.object(ref).take(1);
    }

    getUserDetail(detail): Observable<any> {
        var ref = "users/" + detail;
        return this.af.database.object(ref).take(1);
    }

    setLoginUserDetail(data) {
        this.userDetailInfo = UserInfo.fromJSON(data);
        this.userDetail$.next(UserInfo.fromJSON(data));
    }

    getLoginUserDetail() {
        return this.userDetailInfo;
    }

    getCurrentTicketCount(): Observable<any> {
        let ref = "ticket/ticketCount";
        return this.promiseToObservable(
            this.firebaseApp.database().ref(ref).transaction(function (currentCount) {
                return currentCount + 1;
            }));
    }

    createTicket(ticketNum, ticketData): Observable<TicketInfo> {
        var ref = "ticket/ticketDetail/TIC" + ticketNum;
        this.promiseToObservable(this.af.database.object(ref).set(ticketData));
        return this.af.database.object(ref).take(1);
    }

    addComment(ticketNum, comment): Observable<any> {
        var ref = "ticket/comment/TIC" + ticketNum;
        this.promiseToObservable(this.af.database.list(ref).push(comment));
        return this.af.database.object(ref).take(1);
    }

    updateAttachmentInfo(ticketNum, attachemntInfo): Observable<any> {
        var ref = "ticket/attachemntInfo/TIC" + ticketNum;

        attachemntInfo.forEach(element => {
            this.promiseToObservable(this.af.database.list(ref).push(element));
        });

        return this.af.database.object(ref).take(1);
    }

    addUserState(uid, stateArr) {
        var ref = "user_state/" + uid;
        stateArr.forEach(element => {
            this.promiseToObservable(this.af.database.list(ref).push(element));
        });
    }

    addUserDistrict(uid, distArr) {
        var ref = "user_dist/" + uid;
        distArr.forEach(element => {
            this.promiseToObservable(this.af.database.list(ref).push(element));
        });
    }

    addUserPincode(uid, pinArr) {
        var ref = "user_pin/" + uid;
        pinArr.forEach(element => {
            this.promiseToObservable(this.af.database.list(ref).push(element));
        });
    }

    getPassedNodeData(path): Observable<any> {
        return this.af.database.list(path).take(1);
    }

    getPassedNodeObjectData(path): Observable<any> {
        return this.af.database.object(path).take(1);
    }

    getTicketDetails(area, searchParam) {
        return this.af.database.list("ticket/ticketDetail", {
            query: {
                orderByChild: `dep_${area}`,
                equalTo: "L1_" + searchParam
            }
        }).take(1);
    }

    uploadAttachment(file) {
        const subject = new Subject<any>();
        const storageRef = this.firebaseApp.storage().ref();
        // Create the file metadata
        var metadata = {
            contentType: 'image/jpeg'
        };
        // Upload file and metadata to the object 'images/mountains.jpg'
        var uploadTask = storageRef.child('images/' + file.name).put(file, metadata);

        // Listen for state changes, errors, and completion of the upload.
        uploadTask.on(firebase.storage.TaskEvent.STATE_CHANGED, // or 'state_changed'
            function (snapshot) {
                // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
                var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;

                switch (snapshot.state) {
                    case firebase.storage.TaskState.PAUSED: // or 'paused'
                        console.log('Upload is paused');
                        break;
                    case firebase.storage.TaskState.RUNNING: // or 'running'
                        console.log('Upload is running');
                        break;
                }
            }, function (error) {
                switch (error.code) {
                    case 'storage/unauthorized':
                        // User doesn't have permission to access the object
                        break;
                    case 'storage/canceled':
                        // User canceled the upload
                        break;
                    case 'storage/unknown':
                        // Unknown error occurred, inspect error.serverResponse
                        break;
                }


            }, function () {
                // Upload completed successfully, now we can get the download URL
                subject.next(uploadTask.snapshot);
                subject.complete();
            });

        return subject.asObservable();
    }

    promiseToObservable(promise): Observable<any> {
        const subject = new Subject<any>();
        promise.then(res => {
            subject.next(res);
            subject.complete();
        }, err => {
            subject.error(err);
            subject.complete();
        });
        return subject.asObservable();
    }

}
