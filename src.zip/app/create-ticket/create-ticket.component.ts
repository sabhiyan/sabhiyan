import { Component, OnInit } from '@angular/core';
import { FirebaseService } from '../services/firebase/firebase.service';
import { TicketInfo } from '../models/ticket.info';
import { UserInfo } from '../models/user.info';


@Component({
    selector: 'app-create-ticket',
    templateUrl: './create-ticket.component.html',
    styleUrls: ['./create-ticket.component.css']
})
export class CreateTicketComponent implements OnInit {

    generatedTicket: TicketInfo;
    userInfo: UserInfo;
    comment: any;
    attachementArr: any[] = [];

    constructor(public fireService: FirebaseService) {
    }

    ngOnInit() {
    }

    fileUpload(fileRef) {
        this.fireService.uploadAttachment(fileRef.files[0]).subscribe((res) => {
            let userInfo = this.fireService.getLoginUserDetail();
            this.attachementArr.push({
                location: "L1_127021",
                pincode: "127021",
                uploadedDate: new Date().getTime(),
                userId: userInfo.$key,
                fileLocation: res.downloadURL,
                fileName: fileRef.files[0].name
            });
            if (!this.comment) {
                this.comment = {
                    userId: userInfo.$key,
                    userName: userInfo.userName,
                    createDate: new Date().getTime(),
                    userProfilePic: userInfo.profileImg,
                    commentDes: "Commet has been added",
                    attachmentNames: fileRef.files[0].name
                }
            } else {
                this.comment.attachmentNames += "," + fileRef.files[0].name;
            }

        });
    }

    createTicket() {
        this.fireService.getCurrentTicketCount().subscribe((res) => {
            if (res.committed) {

                let ticketNum = res.snapshot.val();

                this.fireService.createTicket(ticketNum, this.createTicketJSON()).subscribe((res) => {
                    this.generatedTicket = TicketInfo.fromJSON(res);
                });

                this.fireService.addComment(ticketNum, this.comment).subscribe((comment) => {
                    console.log('comment success');
                });

                this.fireService.updateAttachmentInfo(ticketNum, this.attachementArr).subscribe((comment) => {
                    console.log('attachment success');
                });
            }
        });
    }

    updateComment() {
        let userInfo = this.fireService.getLoginUserDetail();

        if (!this.comment) {
            this.comment = {
                userId: userInfo.$key,
                userName: userInfo.userName,
                createDate: new Date().getTime(),
                userProfilePic: userInfo.profileImg,
                commentDes: "",
                attachmentNames: ""
            }
        } else {
            this.comment.commentDes = "Commet has been added";
        }
    }

    createTicketJSON() {
        let userInfo = this.fireService.getLoginUserDetail();
        return {
            createUserId: userInfo.$key,
            createsUserName: userInfo.userName,
            createdUserProfileImg: userInfo.profileImg,
            currAssigneeId: "",
            ticketDec: "Enter by user and it should be of 160 to 180 character, This should be long text",
            createdDate: new Date().getTime(),
            modifyDate: new Date().getTime(),
            ticketStatus: "Open",
            categoryType: "Garbage",
            location: "44.968046_-94.420307",
            localAddress: "Address of the location where clicked",
            district: "BWN",
            state: "HAR",
            pincode: "127021",
            currentAssigneeDep: "L1",
            dep_state: "L1_HAR",
            dep_dist: "L1_BWN",
            dep_pincode: "L1_127021",
            voteup_count: "0"
        };
    }

}
