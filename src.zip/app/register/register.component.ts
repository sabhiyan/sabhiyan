import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../services/firebase/auth.service'
import { FirebaseService } from '../services/firebase/firebase.service'
import { Router } from '@angular/router'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {
  myRegisterForm: FormGroup;

  constructor(private fb: FormBuilder,
    private authService: AuthService,
    private fireService: FirebaseService,
    private route: Router) {

    this.myRegisterForm = this.fb.group({
      email: ['', Validators.required],
      password: ['', Validators.required],
      confirm: ['', Validators.required],
      empid: ['', Validators.required]
    });
  }

  ngOnInit() {
  }

  signUp() {
    let formValue = this.getInputValue();
    this.authService.signUp(formValue.email, formValue.password).subscribe((res) => {

      this.fireService.addUser(res.uid, this.createUserJSON(formValue)).subscribe((res) => {

        this.fireService.setLoginUserDetail(res);
        this.route.navigate(['/dashboard']);

      }, (err) => { console.log(err) });
    },
      err => alert("errro")
    );
  }

  getInputValue() {
    var randomId = Math.random() * 1000000000;
    return {
      email: "guest" + randomId + "@sabhiyan.in",
      password: "123456"
    }
  }

  createUserJSON(input) {
    return {
      userName: "@Guest",
      name: "GuestUser",
      email: input.email,
      telephone: "",
      userType: "User",
      department: "",
      area: "",
      profileImg: ""
    };
  }
}




