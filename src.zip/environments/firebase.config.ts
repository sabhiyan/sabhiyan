import { AuthMethods, AuthProviders } from 'angularfire2/index'

export const firebaseConfig = {
    apiKey: "AIzaSyBGSS3cfuHftBAyKdzSKdFlP1Tt4Owi48c",
    authDomain: "test-174df.firebaseapp.com",
    databaseURL: "https://test-174df.firebaseio.com",
    storageBucket: "test-174df.appspot.com",
    messagingSenderId: "598559312084"
};

export const authConfig = {
    provider: AuthProviders.Password,
    method: AuthMethods.Password
};